// const doma = location.host

// function h(pageTitle,id,url) {
//     history.pushState({
//         id: id
//     }, pageTitle, url);
//     // location.assign(url);
//     windown.onpopstate = function (event) {
//      if (history.state && history.state.id === id) {
//         location.href == url
//         alert(url)
//      }}
// }

// history.pushState({
//     id: 'homepage'
// }, 'Home | My App', 'http://my-app-url.com/?p=homepage');


// windown.onpopstate = function (event) {
//     if (history.state && history.state.id === 'homepage') {
//         // Render new content for the hompage
//     }
// }; or
//  window.addEventListener('popstate', function (event) {
//     if (history.state && history.state.id === 'homepage') {
//         // Render new content for the hompage
//     }
// }, false);

  
  // Whenever the user explicitly chooses dark mode
  
  // Whenever the user explicitly chooses to respect the OS preference